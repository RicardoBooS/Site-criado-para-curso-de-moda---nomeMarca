<div id="rodapeC">
    <div id="rodape">
        <div id="intagram">
            <a href="http://instagram.com/">
                <img src="imagens/insta.png"/>
            </a>
        </div>
    </div>
</div>