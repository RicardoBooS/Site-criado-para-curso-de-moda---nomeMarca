<meta charset="UTF-8">
<title>Modèle Maítre</title>
<link rel="stylesheet" href="style.css" type="text/css"/>
<link rel="icon" href="favicon.ico" type="image/x-icon"/>