<div id="menuC">
    <div id="menu">
        <nav>
            <a href="index.php">Home</a>
            <a href="marca.php">Marca</a>
            <a href="inspiracao.php">Inspiração</a>
            <a href="personagem.php">Personagem</a>
            <a href="colecao.php">Coleção</a>
        </nav>
    </div>    
</div>